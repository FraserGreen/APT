#include <iostream>
using std::cin;
using std::cout;
using std::endl;

int main(void)
{
    cout << "example::foo" << endl;
}