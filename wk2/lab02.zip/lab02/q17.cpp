#include <iostream>
using std::cin;
using std::cout;
using std::endl;

void increment(double &value);
int main(void)
{
    cout << "namespaces, classes, and methods. Not sure about this one." << endl;
}