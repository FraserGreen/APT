#include <iostream>
using std::cin;
using std::cout;
using std::endl;

int main(void)
{
    cout << "A reference is an alias of another variable." << endl;
}