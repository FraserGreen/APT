#include <iostream>
using std::cin;
using std::cout;
using std::endl;

int main(void)
{
    cout << "The character that denotes the end of a string is: '\0'" << endl;
}