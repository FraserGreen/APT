#include <iostream>
using std::cin;
using std::cout;
using std::endl;

int main(void)
{
    cout << "Because a reference is an exact copy (memory and value) of another variable" << endl;
}