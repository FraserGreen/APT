#include <iostream>
using std::cin;
using std::cout;
using std::endl;

int main(void)
{
    cout << "'using namespace std;' is bad style because all of the keywords in the std library are now in use," << endl;
    cout << "While the programmers are likely only using a small number of them." << endl;
}