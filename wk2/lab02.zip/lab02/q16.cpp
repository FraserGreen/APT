#include <iostream>
using std::cin;
using std::cout;
using std::endl;

void increment(double& value);
int main(void)
{
    cout << "A null pointer cannot contain a value, therefore cannot be dereferenced." << endl;
}