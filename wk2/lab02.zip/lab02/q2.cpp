#include <iostream>
using std::cin;
using std::cout;
using std::endl;

int main(void)
{
    cout << "The purpose of a namespace is to differ between variable names that may be shared by different third party imports." << endl;
}