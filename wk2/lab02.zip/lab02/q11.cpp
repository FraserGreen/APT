#include <iostream>
using std::cin;
using std::cout;
using std::endl;

int main(void)
{
    cout << "A pointer is a variable that contains the memory address of another variable." << endl;
}