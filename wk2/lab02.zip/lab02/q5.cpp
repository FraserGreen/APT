#include <iostream>
using std::cin;
using std::cout;
using std::endl;

int main(void)
{
    cout << "Arrays in java are objects, and arrays in C++ are pointers." << endl;
}