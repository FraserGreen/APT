#include <iostream>
using std::cin;
using std::cout;
using std::endl;

int main(void)
{
    cout << "(a) zyxw" << endl;
    cout << "(b) zyxw\0" << endl;
}