#include <iostream>
using std::cin;
using std::cout;
using std::endl;

int main(void)
{
    cout << "Declaration: introduction of a new named object. e.g.: int a;" << endl;
    cout << "Definition: implementation of the object. e.g.: int b;" << endl;
    cout << "Initialisation: assignment of a value to the object. e.g.: int c = 3;" << endl;
}