#include <iostream>
using std::cin;
using std::cout;
using std::endl;

int main(void)
{
    cout << "The purpose of a function prototype is to let the compiler know that there exists a method that will be called from the main" << endl;
    cout << "It also reveals the number and type of parameter(s), and the return value of the method." << endl;
}